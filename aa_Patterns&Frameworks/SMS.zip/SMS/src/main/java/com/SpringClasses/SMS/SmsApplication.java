package com.SpringClasses.SMS;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.SpringClasses.SMS.Model.Student;
import com.SpringClasses.SMS.Repository.StudentRepository;

@SpringBootApplication
public class SmsApplication{
	
	//@Autowired
	//private StudentRepository studentRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(SmsApplication.class, args);
	}
	/*
	 * public void run(String... args) throws Exception { // TODO Auto-generated
	 * method stub Student s = new Student("Sai","Kiran","MS","saikiran@gmail.com");
	 * studentRepository.save(s); }
	 */
	

}
